/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// defined states for the state machine
enum morseCodeWords {SOS, OK} currentWord = SOS;
enum morseCodeLights {G, R, O} subState = R;

// flag to signify that the user wants to change the word
volatile char swapWordFlag = 0;

// variable to count the ticks of the state machine. Initially
// set higher than necessary to force the state machine to
// start the state machine sequence over at the initialization
// of the program
volatile char tickCount = 100;

// Array to define the substates of each main state
enum morseCodeLights SOS_Message[] = {
                 R, O, R, O, R,                     // "S" on red light
                 O, O, O,                           // 1500 ms pause between letters
                 G, G, G, O, G, G, G, O, G, G, G,   // "O" on green light
                 O, O, O,                           // 1500 ms pause between letters
                 R, O, R, O, R,                     // "S" on red light
                 O, O, O, O, O, O, O                // 3500 ms pause between words
};

enum morseCodeLights OK_Message[] = {
                G, G, G, O, G, G, G, O, G, G, G,    // "O" on green light
                O, O, O,                            // 1500 ms pause between letters
                G, G, G, O, R, O, G, G, G,          // "K" on green and red light
                O, O, O, O, O, O, O                 // 3500 ms pause between words
};

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    // state machine for the main states. Will change the current word
    // if necessary, restart the word if necessary, or allow for
    // display of current word to progress
    switch (currentWord) {
        case SOS:
            // end of word reached and swapWordFlag is raised. Move to
            // next word and drop flag
            if (tickCount >= 34 && swapWordFlag) {
                currentWord = OK;
                swapWordFlag = 0;
                tickCount = 0;
                subState = OK_Message[tickCount];
            // end of word but swapWordFlag not raised. Restart word
            } else if (tickCount >= 34) {
                tickCount = 0;
                currentWord = SOS;
                subState = SOS_Message[tickCount];
            // continue display of current word
            } else {
                currentWord = SOS;
                subState = SOS_Message[tickCount];
            }
            break;
        case OK:
            // end of word reached and swapWordFlag is raised. Move to
            // next word and drop flag
            if (tickCount >= 30 && swapWordFlag) {
                currentWord = SOS;
                swapWordFlag = 0;
                tickCount = 0;
                subState = SOS_Message[tickCount];
            // end of word but swapWordFlag not raised. Restart word
            } else if (tickCount >= 30) {
                tickCount = 0;
                currentWord = OK;
                subState = OK_Message[tickCount];
            // continue display of current word
            } else {
                currentWord = OK;
                subState = OK_Message[tickCount];
            }
            break;
        default:
            break;
    }

    // state machine for substates. Used to change lights according
    // to main state (i.e., which word to display)
    switch (subState) {
        // Red light off, green light on
        case G:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            break;
        // Red light on, green light off
        case R:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            break;
        // Both lights off
        case O:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            break;
        default:
            break;
    }

    // increase tick count to count which substate is currently active
    tickCount++;
}

void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    // period of 500 ms
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        /* Failed to initialize timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *  Raises the swapWordFlag which tells the state machine to move to
 *  the next word at the end of the current word.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    swapWordFlag = 1;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *  Raises the swapWordFlag which tells the state machine to move to
 *  the next word at the end of the current word.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    swapWordFlag = 1;
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();
    initTimer();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    return (NULL);
}
